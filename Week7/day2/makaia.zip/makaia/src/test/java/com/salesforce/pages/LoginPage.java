package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

    
    public LoginPage enterUsername(String uname){
       // driver.findElement(By.id("idAttributeValue")).sendKeys("bhuvanesh.moorthy@testleaf.com") 
       // Requirement --> locate username field and enter the username
       clearAndType(locateElement("username"), uname);
       reportStep("Username entered successfully "+uname ,"pass");
       return this;

    }
    public LoginPage enterPassword(String pword){
        clearAndType(locateElement(Locators.XPATH, "//input[@id='password']"),pword);
        reportStep("Password entered successfully "+pword ,"pass");
         return this;

    }
    public HomePage clickLoginButton(){
        // Requirement --> locate username field and Click the button
        click(locateElement(Locators.NAME, "Login"));
         reportStep("Login button clicked successfully" ,"pass");
         return new HomePage();

    }





}
