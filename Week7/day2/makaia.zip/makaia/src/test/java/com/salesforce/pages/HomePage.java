package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

    public HomePage clickAppLauncher(){
        click(locateElement(Locators.XPATH, "//button[@title='App Launcher']/div"));
        reportStep("App laucher is clicked successfully", "pass");
        return this;
    }

}
